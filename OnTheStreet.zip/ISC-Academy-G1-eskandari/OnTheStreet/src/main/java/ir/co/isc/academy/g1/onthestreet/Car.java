/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ir.co.isc.academy.g1.onthestreet;

/**
 *
 * @author rbabaei
 */
public class Car extends Creature {

    public Car(String name, Location loaction) {
        super(name, CreatureType.CAR, loaction);
    }

    @Override
    public void move() {
        System.out.println("I am " + type.name() + " with name " + name + " and my location is " + loaction+".");

    }

    @Override
    public void makeSound() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
