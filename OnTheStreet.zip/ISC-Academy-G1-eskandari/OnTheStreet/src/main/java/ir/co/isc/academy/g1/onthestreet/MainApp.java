/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ir.co.isc.academy.g1.onthestreet;

/**
 *
 * @author R_Babaei
 */
public class MainApp {

    public static void main(String[] args) {
        Street street = new Street();
        street.addCreature(new Car("Neysan ABI", new Location(0, 0)));
        street.addCreature(new Human("Ali", new Location(1,1)));
        street.addCreature(new Animal("dog", new Location(2,2)));
        street.addCreature(new Bicycle("Overlord", new Location(3,2)));
        street.addCreature(new Motor( "BMw",new Location(3,1)));
        street.printCreature();
    }
}
