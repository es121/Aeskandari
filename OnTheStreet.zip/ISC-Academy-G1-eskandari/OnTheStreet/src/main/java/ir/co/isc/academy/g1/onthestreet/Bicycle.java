package ir.co.isc.academy.g1.onthestreet;

public class Bicycle extends Creature{
    public Bicycle(String name, Location loaction) {
        super(name, CreatureType.BICYCLE, loaction);
    }

    @Override
    public void move() {
        System.out.println("I am " + type.name() + " with name " + name + " and my location is " + loaction+".");
    }

    @Override
    public void makeSound() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
