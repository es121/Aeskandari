/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ir.co.isc.academy.g1.onthestreet;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rbabaei
 */
public class Street {
   private int id;
   private String name;
   private String address;
   private List<Creature> creatures ;

    public Street() {
        creatures = new ArrayList<>();
    }
   
    public  void addCreature(Creature creature){
        creatures.add(creature);
    }
    public void printCreature(){
        for (Creature creature : creatures) {
            creature.move();
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<Creature> getCreatures() {
        return creatures;
    }

    public void setCreatures(List<Creature> creatures) {
        this.creatures = creatures;
    }
    
    
   
}
