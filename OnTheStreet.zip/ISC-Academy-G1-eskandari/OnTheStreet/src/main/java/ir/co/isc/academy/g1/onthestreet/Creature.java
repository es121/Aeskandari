/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ir.co.isc.academy.g1.onthestreet;

/**
 *
 * @author rbabaei
 */
public abstract class Creature {

    protected String name;
    protected CreatureType type;
    protected Location loaction;

    public Creature(String name, CreatureType type, Location loaction) {
        this.name = name;
        this.type = type;
        this.loaction = loaction;
    }

    public abstract void move();

    public abstract void makeSound();
}
