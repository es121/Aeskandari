package ir.co.isc.academy.g1.onthestreet;

public class Animal extends Creature{
    public Animal(String name, Location loaction) {
        super(name, CreatureType.ANIMAL , loaction);
    }

    @Override
    public void move() {
        System.out.println("I am " + type.name() + " with name " + name + " and my location is " + loaction+".");
    }

    @Override
    public void makeSound() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
